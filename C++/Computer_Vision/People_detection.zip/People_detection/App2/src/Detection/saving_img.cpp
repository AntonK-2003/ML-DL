#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
using namespace cv;
int saving_img(img)
{
 std::string image_path = samples::findFile(img);
 std::string choice_img;
 Mat img = imread(image_path, IMREAD_COLOR);
 if(img.empty())
 {
 std::cout << "Could not read the image: " << image_path << std::endl;
 return 1;
 }
 imshow("Display window", img);
 int k = waitKey(0); // Wait for a keystroke in the window
 if(k == 's')
 {
    if choice_img == "png"
    {
        imwrite("out.png", img);
    }
    else if choice_img == "bmp"
    {
        imwrite("out.bmp", img);
    }
    else if choice_img == "jpg"
    {
        imwrite("out.jpg", img);
    }
    else if choice_img == "gif"
    {
        imwrite("out.gif", img);
    }
 }
 return 0;
}
