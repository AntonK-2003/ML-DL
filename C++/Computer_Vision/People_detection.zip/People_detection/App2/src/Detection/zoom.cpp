void COpenCVWindowExt::RefreshImage ()
{
	if (m_matSrc.empty ())
		return;
	Mat matResize;
	Size size (int (m_dNewScale * m_matSrc.cols), int (m_dNewScale * m_matSrc.rows));
	resize (m_matSrc, matResize, size);
	int iW = int (m_matSrc.cols * m_dInitialScale), iH = int (m_matSrc.rows * m_dInitialScale);

	Rect rectShow (Point (m_iHorzScrollBarPos, m_iVertScrollBarPos), Size (iW, iH));
	imshow (m_strWindowName, matResize (rectShow));
}
