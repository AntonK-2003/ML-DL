CREATE DATABASE NOT EXIST visionanalysis;
USE visionanalysis;
CREATE TABLE geteddata (
videodate date,
pn int,
id id,
coordinates float)
