#include <stdio.h>
#include <iostream>
#include "highgui.h"
#include <chrono>
#include <sql.h>

using namespace std;
using namespace cv2;

int main(void)
{
    int lotsize; //размер партии
    float ss; //степень сигнала
    float sfqу; //вычитание из количества
    float slp; //уровень сигнала до человека
    float slo; // уровень сигнала до объекта
    bool n;
    bool s; //
    int choice_nn; //выбор нейронной сети
    
    /*
    cout << "Размер партии: ";
    cin >> lotsize;
    cout << "Степень сигнала: ";
    cin >> ss;
    cout << "Вычитание из количества: ";
    cin >> sfqy;
    cout << "Уровень сигнала до человека: ";
    cin >> slp;
    cout << "Уровень сигнала до объекта: ";
    cin >> slo;
    cout << "Нормализация изображений:";
    cin >> n;
    cout << "Отправлять ли объекты:";
    cin >> s;
    cout << "Выбор нейронной сети:";
    //cin >>*/
    int cs;
    #pragma omp parallel
    {
    #pragma omp for
        cam1;
        cam2;
        cam3;
        cam4;
        scroll();
        lotsize = new WLineEdit(root());                     // allow text input
        lotsize->setFocus();
        __fastcall TForm1::Button1Click(TObject *Sender);
    while(true)
    {
        float coordinates;
        cvNamedWindow( "CAM Capture", CV_WINDOW_AUTOSIZE );
        CvCapture* capture = cvCreateCameraCapture(-1);
        assert(capture != NULL);
        IplImage* frame;
        while(1)
        {
            if *button3 = true
            {
                calibrate();
            }
            frame = cvQueryFrame( capture );
            if( !frame ) break;
            cvShowImage( "CAM Capture", frame );
            char c = cvWaitKey(33);
            if( c == 27 ) break;
            }
            cvReleaseCapture( &capture );
            cvDestroyWindow( "CAM Capture" );
            
            switch(choice_nn)
            {
                case 1:
                    YOLO();
                break
                case 2:
                    ONNX();
                break
            }
            float = imsize(img);
            //return img;
            if *button4 = true
            {
                saving_img(img);
            }
            auto now = std::chrono::system_clock::now();
            std::time_t end_time = std::chrono::system_clock::to_time_t(now);
        
            std::cout << "Current Time and Date: " << std::ctime(&end_time) << std::endl;
            INSERT INTO gateddata values (4, capture ,LOAD_FILE("файловый путь сохранения"));
            INSERT INTO gateddata values (videodate, &end_time);
            INSERT INTO gateddata values (pn, );
            INSERT INTO gateddata values (coordinates, coordinates);
            //return &end_time, capture
            root()->addWidget(new WText("Сортировка по: (выберите числа)"));
            root()->addWidget(new WText("1. Дате и времени"));// show some text
            root()->addWidget(new WText("2. Количеству людей"));
            root()->addWidget(new WText("3. Координатам"))
            cs = scanf();
            switch(cs)
            {
                case 1:
                    FROM gateddata SELECT values(videodate);
                    break;
                case 2:
                    FROM gateddata SELECT values(pn);
                    break;
                case 3:
                    FROM gateddata SELECT values(coordinates);
                    break;
            }
    }
}

int calibrate(int, char**)
{
    VideoCapture cap(0); // открываем камеру
    if(!cap.isOpened())  // 

    Mat edges;
    namedWindow("edges",1);
    for(;;)
    {
        Mat frame;
        cap >> frame; // получаем кадры от камеры
        cvtColor(frame, edges, COLOR_BGR2GRAY);
        GaussianBlur(edges, edges, Size(7,7), 1.5, 1.5);
        Canny(edges, edges, 0, 30, 3);
        imshow("edges", edges);
        if(waitKey(30) >= 0) break;
    }
    // деструктор
    return 0;
}
