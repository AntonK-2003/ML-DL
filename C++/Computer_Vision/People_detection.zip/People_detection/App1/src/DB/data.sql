CREATE DATABASE NOT EXIST visionanalysis;
USE visionanalysis;
CREATE TABLE geteddata (
videodate date,
pn int,
id id,
coordinates float,
INSERT INTO gateddata values (3, 'cva.avi',LOAD_FILE("файловый путь сохранения"));
