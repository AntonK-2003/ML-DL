#include <vcl.h>
#include <vfw.h>  //Подлючаем библиотеку VFW (Video for Windows)
HWND MyWebCam; //Подключаем дискриптор форточек (окон)
#pragma hdrstop
 
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  MyWebCam=capCreateCaptureWindowA("Name My WEB Cam",WS_CHILD | WS_VISIBLE | WS_CAPTION, 0,0,1920,1080,Handle,0);
  capDriverConnect (MyWebCam,0); //Подключаемся
  bool OK=false;
    for ( int i=0 ; i<10 ; i++ )
        if ( capDriverConnect(hVFWwin,i) ) {
            Label2->Caption=i;    //вывод инфы о номере драйвера
            OK=true;    break;
        }
    if ( !OK ) {
        DestroyWindow(hVFWwin);
        ShowMessage("Невозможно подключить драйвер видеозахвата!");
        return false;
    }
  capPreviewRate (MyWebCam,30); //Выставили частоту кадров
  capPreview (MyWebCam,True); //Смотрим
}
