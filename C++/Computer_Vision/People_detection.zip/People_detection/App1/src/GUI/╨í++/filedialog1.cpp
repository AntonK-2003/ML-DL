#include <Wt/WApplication>
#include <Wt/WBreak>
#include <Wt/WContainerWidget>
#include <Wt/WLineEdit>
#include <Wt/WPushButton>
#include <Wt/WText>

using namespace Wt;

int lotsize; //размер партии
float ss; //степень сигнала
float sfqу; //вычитание из количества
float slp; //уровень сигнала до человека
float slo; // уровень сигнала до объекта
bool n; //отпраление объектов
bool s; //
int choice_nn; //выбор нейронной сети

/*
 * A simple hello world application class which demonstrates
 * how to react to events, read input, and give feed-back.
 */
class VisionApplication : public WApplication
{
public:
  VisionApplication(const WEnvironment& env);

private:
  WLineEdit *nameEdit_;
  WText *greeting_;

  void greet();
};

/*
 * The env argument contains information about the new session, and
 * the initial request. It must be passed to the WApplication
 * constructor so it is typically also an argument for your custom
 * application constructor.
*/
VisionApplication::VisionApplication(const WEnvironment& env)
  : WApplication(env)
{
  setTitle("Computer Vison, cam1");                               // application title

  root()->addWidget(new WText("Размер партии: "));  // show some text
  lotsize = new WLineEdit(root());                     // allow text input
  lotsize->setFocus();
  return lotsize;
  
  root()->addWidget(new WText("Степень сигнала: "));  // show some text
  ss = new WLineEdit(root());                     // allow text input
  ss ->setFocus();// give focus
  return ss;
  
  root()->addWidget(new WText("Вычитание из количества: "));  // show some text
  sfqy = new WLineEdit(root());                     // allow text input
  sfqy ->setFocus();
  return sfqy;
  
  root()->addWidget(new WText("Уровень сигнала до человека: "));  // show some text
  slp = new WLineEdit(root());                     // allow text input
  slp ->setFocus();
  return slp;
  
  root()->addWidget(new WText("Уровень сигнала до объекта: "));  // show some text
  slo = new WLineEdit(root());                     // allow text input
  slo ->setFocus();
  return slo;
  
  root()->addWidget(new WText("Нормализация изображений:"));  // show some text
  n = new WLineEdit(root());                     // allow text input
  n ->setFocus();
  return n;
  
  root()->addWidget(new WText("Отправлять ли объекты: д/н"));  // show some text
  s = new WLineEdit(root());                     // allow text input
  set->setFocus();
  return s;
  
  root()->addWidget(new WText("Выбор нейронной сети:"));
  root()->addWidget(new WText("1. YOLOv5"));
  root()->addWidget(new WText("2. ONNX"))  // show some text
  choice_nn = new WLineEdit(root());                     // allow text input
  choice_nn->setFocus();
  return choice_nn;
  
  
  WPushButton *button1
    = new WPushButton("Запуск", root());              // create a button
  button2->setMargin(5, Left);
  if *button1 == true:// add 5 pixels margin
        switch(choice_nn)
            case 1:
                
      
  WPushButton *button2
    = new WPushButton("Останов", root());              // create a button
  button2->setMargin(6, Left); 
  
  root()->addWidget(new WBreak());                       // insert a line break

  greeting_ = new WText(root());                         // empty text

  /*
   * Connect signals with slots
   *
   * - simple Wt-way
   */
  button->clicked().connect(this, &VisionApplication::greet);

  /*
   * using an arbitrary function object
   * (binding values with boost::bind())
   */
  nameEdit_->enterPressed().connect
    (boost::bind(&VisionApplication::greet, this));
}

void VisionApplication::greet()
{
  /*
   * Update the text, using text input into the nameEdit_ field.
   */
  greeting_->setText("Анализ видео компьютерным зрением " + nameEdit_->text());
}

WApplication *createApplication(const WEnvironment& env)
{
  /*
   * You could read information from the environment to decide whether
   * the user has permission to start a new application
   */
  return new VisionApplication(env);
}

int cam1(int argc, char **argv)
{
  /*
   * Your main method may set up some shared resources, but should then
   * start the server application (FastCGI or httpd) that starts listening
   * for requests, and handles all of the application life cycles.
   *
   * The last argument to WRun specifies the function that will instantiate
   * new application objects. That function is executed when a new user surfs
   * to the Wt application, and after the library has negotiated browser
   * support. The function should return a newly instantiated application
   * object.
   */
  return WRun(argc, argv, &createApplication);
}
