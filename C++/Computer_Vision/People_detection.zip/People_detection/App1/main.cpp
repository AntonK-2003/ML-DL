#include <stdio.h>
#include <iostream>
#include "highgui.h"
#include <chrono>

using namespace std;
using namespace cv2;

int main(void)
{
    int cs;
    #pragma omp parallel
    {
    #pragma omp for
        cam1;
        cam2;
        cam3;
        cam4;
        scroll();
        root()->addWidget(new WText("Сортировка по: (выберите числа)"));
        root()->addWidget(new WText("1. Дате и времени"));// show some text
        root()->addWidget(new WText("2. Количеству людей"));
        root()->addWidget(new WText("3. Координатам"))
        cs = scanf();
        switch(cs)
        {
            case 1:
                
                break;
            case 2:
                
                break;
                
            case 3:
                break;
        }
        lotsize = new WLineEdit(root());                     // allow text input
        lotsize->setFocus();
        __fastcall TForm1::Button1Click(TObject *Sender);
    while(true)
    {
        cvNamedWindow( "CAM Capture", CV_WINDOW_AUTOSIZE );
        CvCapture* capture = cvCreateCameraCapture(-1);
        assert(capture != NULL);
        IplImage* frame;
        while(1)
        {
        calibrate();
        frame = cvQueryFrame( capture );
        if( !frame ) break;
        cvShowImage( "CAM Capture", frame );
        char c = cvWaitKey(33);
        if( c == 27 ) break;
        }
        cvReleaseCapture( &capture );
        cvDestroyWindow( "CAM Capture" );
        switch(choice_nn)
        {
            case 1: 
                YOLO();
                break;
            case 2: 
                ONNX();
                break;
        }
        story();
    }
}
        imsize(img);
        auto now = std::chrono::system_clock::now();
        std::time_t end_time = std::chrono::system_clock::to_time_t(now);
    
        std::cout << "Current Time and Date: " << std::ctime(&end_time) << std::endl;
    }
}

int calibrate(int, char**)
{
    VideoCapture cap(0); // открываем камеру
    if(!cap.isOpened())  // 

    Mat edges;
    namedWindow("edges",1);
    for(;;)
    {
        Mat frame;
        cap >> frame; // получаем кадры от камеры
        cvtColor(frame, edges, COLOR_BGR2GRAY);
        GaussianBlur(edges, edges, Size(7,7), 1.5, 1.5);
        Canny(edges, edges, 0, 30, 3);
        imshow("edges", edges);
        if(waitKey(30) >= 0) break;
    }
    // деструктор
    return 0;
}


