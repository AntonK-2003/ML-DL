buildscript {
	repositories {
		mavenCentral()
	}
}

plugins {
	id 'org.springframework.boot' version '2.5.2'
	id 'io.spring.dependency-management' version '1.0.11.RELEASE'
	id 'java'
}

group = 'com.parsing'
version = '0.0.1-SNAPSHOT'
sourceCompatibility = '11'

configurations {
	compileOnly {
		extendsFrom annotationProcessor
	}
}

repositories {
	mavenCentral()
}

dependencies {
	implementation 'org.springframework.boot:spring-boot-starter-web:2.6.2'
	implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
	implementation group: 'org.apache.httpcomponents', name: 'httpclient', version: '4.5'
	implementation 'org.postgresql:postgresql:42.3.1'
	implementation 'org.projectlombok:lombok:1.18.22'

	compileOnly 'org.projectlombok:lombok:1.18.22'
	annotationProcessor 'org.projectlombok:lombok:1.18.22'

	testImplementation 'org.springframework.boot:spring-boot-starter-test'
}

test {
	useJUnitPlatform()
}

# connected to JDBC
# setup spring.datasource
spring.datasource.driver-class-name=org.postgresql.Driver
spring.datasource.url=jdbc:postgresql://localhost:5432/change-me
spring.datasource.username=change-me
spring.datasource.password=change-me
spring.datasource.hikari.connection-timeout=30000
spring.datasource.hikari.idle-timeout=60000
spring.datasource.hikari.maximum-pool-size=120

# setup hibernate
spring.jpa.show-sql=true
spring.jpa.generate-ddl=true
spring.jpa.hibernate.ddl-auto=create-drop
spring.jpa.properties.hibernate.show_sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.proc.param_null_passing=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.PostgreSQL94Dialect

@XmlRootElement(name = "ValCurs")
@XmlAccessorType(XmlAccessType.FIELD)
public class CourseDto implements Serializable {

    @XmlElement(name = "Valute")
    private List<CourseDtoOnce> valute;
    @XmlElement(name = "Date")
    private LocalDate date;

    public List<CourseDtoOnce> getValute() {
        return valute;
    }

    @Override
    public String toString() {
        return "CourseDto{" +
                "valute=" + valute +
                ", date=" + date +
                '}';
    }
}

@Entity
@XmlRootElement(name = "Valute")
@XmlAccessorType(XmlAccessType.FIELD)
public class CourseDtoOnce implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @XmlElement(name = "NumCode")
    private String numCode;

    @XmlElement(name = "CharCode")
    private String charCode;

    @XmlElement(name = "Nominal")
    private int nominal;

    @XmlElement(name = "Name")
    private String name;

    @XmlElement(name = "Value")
    @JsonIgnore
    @Transient
    private String _Value;

    private double value;

    public String get_Value() {
        return _Value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "\n" + name + " (" +
                "numCode = " + numCode + ", " +
                "charCode = " + charCode + ", " +
                "nominal = " + nominal + ", " +
                "value = " + value + ")";
    }
}

public interface CourseEntityRepository extends JpaRepository<CourseDtoOnce, Long> {
}

@Component
public class CourseClient {
    public static final String URL = "https://cbr.ru/scripts/XML_daily.asp?date_req=23/01/2022.xml";

    final RestTemplate restTemplate = new RestTemplate();


    public List<CourseDtoOnce> getCourses() {
        CourseDto response = restTemplate.getForObject(URL, CourseDto.class);

        if (response != null) {
            response
                    .getValute()
                    .forEach(x -> {
                        x.setValue(Double.parseDouble(x.get_Value().replace(",", ".")));
                        System.out.println(x);
                    });

            return response.getValute();
        }

        return null;
    }
}

@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseEntityRepository courseEntityRepository;
    private final CourseClient courseClient;

    public List<CourseDtoOnce> findCourseInfo(){
        return courseEntityRepository.saveAll(courseClient.getCourses());
    }
}

@RestController
@RequiredArgsConstructor
public class CourseParsingController {

    private final CourseService courseService;

    /**
     * Возвращает список курсов валют
     *
     * @return список курсов валют
     */
    @GetMapping(value = "/getCourse")
    public String getListInformation() {
        return courseService.findCourseInfo().toString();
    }
}

@SpringBootApplication
public class ParsingProjectApplication {
	public static void main(String[] args) {
		SpringApplication.run(ParsingProjectApplication.class, args);
	}
}

