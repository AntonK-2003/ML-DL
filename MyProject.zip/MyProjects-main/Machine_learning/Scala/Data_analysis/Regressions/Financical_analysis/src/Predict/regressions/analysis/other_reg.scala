 import smile.data.{AttributeDataset, NumericAttribute}
 import smile.read
 import smile.regression.{LASSO, RidgeRegression, lasso, ridge}
 
val data: AttributeDataset = read.table("regression.txt", delimiter = " ", response = Some((new NumericAttribute("class"), 0)))
 val x: Array[Array[Double]] = data.x()
 val y: Array[Double] = data.y()
 val ridgeRegression: RidgeRegression = ridge(x, y, 0.0057)
 val lassoRegression: LASSO = lasso(x, y, 10)
 println(ridgeRegression)
 println(lassoRegression)
