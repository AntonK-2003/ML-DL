Линейная регрессия с градиентным спуском на Scala с использованием Apache Spark (Spark ML)

Руководство:

1. Установите scala по документации:

https://docs.scala-lang.org/ru/getting-started/index.html

2. Загрузите и установите Apache Spark, Breeze, Vegas

3. Перейдите в каталог Regression.src.ml,spark.regression

4. Скомпилируйте:

scalac linreg.scala

5. Запустите:

scala linreg
