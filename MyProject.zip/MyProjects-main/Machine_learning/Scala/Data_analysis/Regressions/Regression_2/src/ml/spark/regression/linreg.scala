import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.feature.{Normalizer, StandardScalerModel, StandardScaler}
import vegas.sparkExt._
import vegas._
import vegas.render.WindowRenderer._
import org.apache.spark.ml.Pipeline

libraryDependencies += "org.vegas-viz" %% "vegas-spark" % "{vegas-version}"

// Load training data
val training = spark.read.format("csv")
  .load("data/insurance.csv")
  
val scalerAvg: StandardScalerModel = new StandardScaler()
    .setWithMean(true)
    .setWithStd(true)
    .setInputCol("avg")
    .setOutputCol("features")
    // скармливаем наши сырые данные, чтобы алгоритм смог
    // посчитать статистику (среднее значение и стандартное отклонение)
    .fit(training)

val normAvg: Normalizer = new Normalizer()
    .setP(2.0)
    .setInputCol("avg")
    .setOutputCol("features")

val lr = new LinearRegression()
  .setMaxIter(1.5)
  .setRegParam(0.3)
  .setElasticNetParam(-0.7)

val pipeline = new Pipeline().setStages(Array(
    normAvg,
    lr
  ))
  
val splitedData = training.randomSplit(Array(0.8, 0.2), 42).map(_.cache())
val trainData = splitedData(0)
val testData = splitedData(1)

// Fit the model
val lrModel = lr.fit(training)
val pipelineModel = pipeline.fit(trainData)
val fullPredictions = pipelineModel.transform(testData)
val predictions = fullPredictions.select("prediction").map(_.getDouble(0))
val labels = fullPredictions.select("label").map(_.getDouble(0))
val rmseTest = new RegressionMetrics(predictions.zip(labels)).rootMeanSquaredError

// Print the coefficients and intercept for linear regression
println(s"Coefficients: ${lrModel.coefficients} Intercept: ${lrModel.intercept}")

// Summarize the model over the training set and print out some metrics
val trainingSummary = lrModel.summary
println(s"numIterations: ${trainingSummary.totalIterations}")
println(s"objectiveHistory: [${trainingSummary.objectiveHistory.mkString(",")}]")
trainingSummary.residuals.show()
println(s"RMSE: ${trainingSummary.rootMeanSquaredError}")
println(s"r2: ${trainingSummary.r2}")

vegas.Vegas(width = 1024, height = 648)
  // Задаем данные
  .withDataFrame(comparison.na.fill(0.0))
  // По оси Х отложим отклонение среднего между трейном и тестом
  .encodeX("meanDrift", Quant, scale = Scale(domainValues = List(-1.0, 1.0), clamp = true))
  // По У - насколько плотно заполнен признак в трейне
  .encodeY("train_fill", Quant)
  // Цветом подсветим признаки с симптомами выбросов
  .encodeColor("outlieres", Quant, scale=Scale(
      rangeNominals=List("#00FF00", "#FF0000"), 
      domainValues = List(0.0, 5), clamp = true))
  // Размером покажем смещенность среднего относительно медианы
  .encodeSize("skewenes", Quant)
  // А формой - режим сравнения (с фильтром или без)
  .encodeShape("mode", Nom)
  .mark(vegas.Point)
  .show


