import datatime
import pyttsx3
import speech_recognition as sr
import os
from bs import BeautifulSoup
import requests


run_voice = True
tts = pyttsx3.init()
voices = tts.getProperty('voice')
for voice in voices:
    if voice.name == "Aleksandr":
        tts.setProperty('voice', voice.id)

while run_voice == True:
    rec = sr.Recognizer()
    with sr.Microphone(device_index = 1) as source:
        print("Готов")
        audio = rec.listen(source)
    query = rec.recognize_google(audio, language = 'ru-Ru', language = 'en-En')
    x = query.lower()
    a = x[0].upper()
    c = len(x)
    b = x[1:c]
    print("-->"+a + b)
    if x == "привет":
        tts.say("Здравствуйте. Как ваше настроение и дела?")
        tts.runAndWait()
    elif x == "сколько времени" or x == "который час":
        a = datetime.datetime.now()
        tts.say("Сейчас" + str(a.hour) + "Часов" + str(a.minute) + "Минут")
        tts.runAndWait()
    elif x == "курс валют Forex":
        exrates = {}
        url = "https://alfaforex.ru/analytics/analytics-currencies/"
        bs = BeautifulSoup(response.text,"lxml")
        cpair = bs.find("course__symbols column")
        cpair = cpair.text
        exrates["currency pair"] == cpair
        course = bs.find("course__value column column_lg-6 column_md-12 column_xs-12")
        course = course.text
        exrates[cpair] == course
    elif x ==  "До свидания" or x == "Пока":
        tts.say("До свидания!")
        tts.runAndWait()
        run_voice = False
    else:
        tts.say("Неизвестная команда")
        tts.runAndWait()
    
    
