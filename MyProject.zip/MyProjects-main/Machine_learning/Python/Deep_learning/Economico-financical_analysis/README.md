A program for trading with approximate rate prediction using deep learning technologies using the Keras and Scikit-learn libraries.
