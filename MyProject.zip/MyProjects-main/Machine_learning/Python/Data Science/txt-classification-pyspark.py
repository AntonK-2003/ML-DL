from pyspark.sql import SQLContext
from pyspark import SparkContext
from pyspark.sql.functions import col
from pyspark.ml.feature import RegexTokenizer, StopWordsRemover, CountVectorizer
from pyspark.ml.classification import LogisticRegression
from pyspark.ml import Pipeline
from pyspark.ml.feature import OneHotEncoder, StringIndexer, VectorAssembler
from pyspark.ml.feature import HashingTF, IDF
from pyspark.ml.classification import NaiveBayes
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator

sc =SparkContext()
sqlContext = SQLContext(sc)

df = sqlContext.read.format('com.databricks.spark.csv').options(header='true', inferschema='true').load('train.csv')

drop_list = ['Dates', 'DayOfWeek', 'PdDistrict', 'Resolution', 'Address', 'X', 'Y']

df = df.select([column for column in data.columns if column not in drop_list])
df.printSchema()
df.groupBy("Category") \
    .count() \
    .orderBy(col("count").desc()) \
    .show()

df.groupBy("Descript") \
    .count() \
    .orderBy(col("count").desc()) \
    .show()

# tokenezation
token = RegexTokenizer(inputCol="Descript", outputCol="words", pattern="\\W")

# stopwords
add_stopwords = ["http","https","amp","rt","t","c","the"]
stopwordsRemover = StopWordsRemover(inputCol="words", outputCol="filtered").setStopWords(add_stopwords)

# wordsset
countVectors = CountVectorizer(inputCol="filtered", outputCol="features", vocabSize=10000, minDF=5)
label_stringIdx = StringIndexer(inputCol = "Category", outputCol = "label")

pipeline = Pipeline(stages=[regexTokenizer, stopwordsRemover, countVectors, label_stringIdx])
pipelineFit = pipeline.fit(data)

dataset = pipelineFit.transform(data)
dataset.show(5)
# do seed
(trainData, testData) = dataset.randomSplit([0.7, 0.3], seed = 100)

print("Training Dataset Count: " + str(trainData.count()))
print("Test Dataset Count: " + str(testData.count()))
logr = LogisticRegression(maxIter=20, regParam=0.3, elasticNetParam=0)
logr_model = logr.fit(trainingData)
predict = logr_model.transform(testData)

predict.filter(predict['prediction'] == 0) \
    .select("Descript","Category","probability","label","prediction") \
    .orderBy("probability", ascending=False) \
    .show(n = 10, truncate = 30)
hashingTF = HashingTF(inputCol="filtered", outputCol="rawFeatures", numFeatures=10000)
idf = IDF(inputCol="rawFeatures", outputCol="features", minDocFreq=5) #minDocFreq: remove sparse terms
pipeline = Pipeline(stages=[token, stopwordsRemover, hashingTF, idf, label_stringIdx])

pipelineFit = pipeline.fit(data)
dataset = pipelineFit.transform(data)

(trainingData, testData) = dataset.randomSplit([0.7, 0.3], seed = 100)
logr = LogisticRegression(maxIter=20, regParam=0.3, elasticNetParam=0)
logr_model = logr.fit(trainData)

predict = lr_model.transform(testData)
evaluator = MulticlassClassificationEvaluator(predictionCol="prediction")
evaluator.evaluate(predict)
pipeline = Pipeline(stages=[token, stopwordsRemover, countVectors, label_stringIdx])

pipelineFit = pipeline.fit(df)
dataset = pipelineFit.transform(df)
(trainData, testData) = dataset.randomSplit([0.7, 0.3], seed = 100)

logr = LogisticRegression(maxIter=20, regParam=0.3, elasticNetParam=0)

# Создание ParamGrid для кросс-валидации
paramGrid = (ParamGridBuilder()
             .addGrid(logr.regParam, [0.1, 0.3, 0.5])
             .addGrid(logr.elasticNetParam, [0.0, 0.1, 0.2])
#            .addGrid(model.maxIter, [10, 20, 50]) #Количество итераций
#            .addGrid(idf.numFeatures, [10, 100, 1000]) #Количество признаков
             .build())

cv = CrossValidator(estimator=logr, \
                    estimatorParamMaps=paramGrid, \
                    evaluator=evaluator, \
                    numFolds=5)
cv_model = cv.fit(trainingData)

predict = cv_model.transform(testData)
# Оценка лучшей модели
evaluator = MulticlassClassificationEvaluator(predictionCol="prediction")
evaluator.evaluate(predict)
nb = NaiveBayes(smoothing=1)
model = nb.fit(trainData)

predict = model.transform(testData)
predict.filter(predict['prediction'] == 0) \
    .select("Descript","Category","probability","label","prediction") \
    .orderBy("probability", ascending=False) \
    .show(n = 10, truncate = 30)
rfc = RandomForestClassifier(labelCol="label", \
                            featuresCol="features", \
                            numTrees = 100, \
                            maxDepth = 4, \
                            maxBins = 32)

rfc_model = rfc.fit(trainingData)

predict = rfc_model.transform(testData)

predict.filter(predict['prediction'] == 0) \
    .select("Descript","Category","probability","label","prediction") \
    .orderBy("probability", ascending=False) \
    .show(n = 10, truncate = 30)
evaluator = MulticlassClassificationEvaluator(predictionCol="prediction")
evaluator.evaluate(predictions)
