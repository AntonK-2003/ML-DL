from nummethods import difeq
from nummethods import linalg
from nummethods import matan
from nummethods import optimization
from nummethods import inteq
from nummethods import high_algebra
from recognition import cv

menu = [
      {'problem': 'high_algebra', 'choices': ["", "государственный", "нет"]},
      {'problem': 'linalg', 'choices': ["компактный", "дисперсный", "компактный и дисперсный"]},
      {'problem': 'matan problem', 'choices': ["высокая", "средняя", "низкая"]},
      {'problem': 'difeq', 'choices': ["Метод Рунге-Кутта", "Метод Эйлера"]},
      {'problem': 'inteq', 'choices': ["Метод разностей", "Метод последовательных приближений", "Метод Галёркина"]},
      {'problem': 'optimization', 'choices': ["высокая", "средняя", "низкая"]}
      {'problem': 'lineqsys', 'choices': ["Метод Крамера", "Метод Гаусса", "Метод Зейделя", "Метод Якоби"]}
    ]

#get image with math problem
file_path = input()
mathproblem_detection(file_path)
classification(file_path)

print("Выберите метод решения(введите число или числа через пробел, если нужны несколько):")
if prediction == "inteq":
    print("1. Метод разностей")
    print("2. Метод последовательных приближений")
    print("3. Метод Галёркина")
    s = input().split()
elif prediction == "difeq":
    print("1. Метод Рунге-Кутта")
    print("2. Метод Эйлера")
    s = input().split()
elif prediction == "non-lineq":
    print("1. Метод Ньютона")
    print("2. Метод дихотомии")
    print("3. Метод простых интераций")
    print("4. Метод секущих")
    s = input().split()
elif prediction == "lineqsys":
    print("1. Метод Крамера")
    print("2. Метод Гаусса")
    print("3. Метод Зейделя")
    print("4. Метод Якоби")
    s = input().split()
elif prediction == "matan problem":
    print("1. Найти производную")
    print("2. Найти первообразную")
    print("3. Численное интегрирование")
    print("4. Численное дифференцирование")
    print("5. Интерполяция")
    s = input().split()
elif prediction == "optimization":
    print("1. Градиентный спуск")
    print("2. Методы линейного программирования")
    print("3. Методы нелиейного программирования")
    print("4. Методы условной оптимизации")
    print("5. Методы безусловной оптимизации")
    s = input().split()
    

