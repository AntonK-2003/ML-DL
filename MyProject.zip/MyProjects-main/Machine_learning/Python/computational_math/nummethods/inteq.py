def difference_method():
    
    
def Galerkin():
    
    
def successive_approximations()
