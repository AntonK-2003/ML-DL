from src.predict import DTR
from src.predict import GBT
from src.predict import LR
from src.predict import SVM

def mean()
    p1 = DTR()
    p2 = SVM()
    p3 = GBT()
    p4 = LR()
    P = (p1 + p2 + p3 + p4)/4
    return P

print(mean())
