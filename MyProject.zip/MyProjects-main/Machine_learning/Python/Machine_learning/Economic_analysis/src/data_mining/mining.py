from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import pandas as pd
import time
from bs4 import BeautifulSoup
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

option = Options()
option.add_argument("--disable-infobars") 
browser = webdriver.Chrome('C:\webdr\chromedriver.exe',chrome_options=option)
# 'https://xn--90adear.xn--p1ai/check/auto' –  ГИБДД.РФ
browser.get('https://xn--90adear.xn--p1ai/check/auto')

elem  =  browser.find_element(By.ID,  'checkAutoVIN' )
elem.send_keys('5GRGXXXXXXX129289' + Keys.RETURN)

share =  browser.find_element(By.CLASS_NAME,  'checker' )
share.click()

elements = soup.find_all(attrs={"class":{"ownershipPeriods-from", "field vehicle-model", "field vehicle-year", "ownershipPeriods-to", "simplePersonType"}})
elements1=soup.find_all(attrs={"class":{"ownershipPeriods-from"}})
elements2=soup.find_all(attrs={"class":{"ownershipPeriods-to"}})
elements3=soup.find_all(attrs={"class":{"simplePersonType"}})
elements4=soup.find_all(attrs={"class":{"field vehicle-model"}})
elements5=soup.find_all(attrs={"class":{"field vehicle-year"}})

df = pd.DataFrame({'VIN': [],  'С': [], 'По': [], 'Владелец': [], 'Марка или модель':[], 'Год выпуска':[]})

for j in range(len(elements1)):
    df1 = df1.append({'VIN': '5GRGXXXXXXX29289', 'Марка или модель':elements4[j].text, 'Год выпуска':elements5[j].text, 'С': elements1[j].text, 'По': elements2[j].text, 
                    'Владелец':elements3[j].text}, ignore_index=True)
    
elementserr=soup.find_all(attrs={"class":{"check-space check-message"}})
if elementserr[0].text=='По указанному VIN не найдена информация о регистрации транспортного средства.':
        ermes=elementserr[0].text
        
while elementserr[0].text=='При получении ответа сервера произошла ошибка.':
        share.click()
        time.sleep(4)

vin=pd.read_excel(r'C:\Users\grvla\Desktop\Парс.xlsx')
sh=0
ermes=''
for i in vin.vins:
    if i in df.VIN.unique():
        continue
