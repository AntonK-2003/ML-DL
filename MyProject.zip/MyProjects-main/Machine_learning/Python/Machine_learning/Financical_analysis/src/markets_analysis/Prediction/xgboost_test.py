import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingRegressor as GDBSklearn
import numpy as np
import xgboost

def XGBoost(df):
    X = np.array(df["Date"])
    y = np.array(df["Price"])

    er_boosting_bagging = get_metrics(X,y,30,GradientBoosting(max_depth=3, n_estimators=150,base_tree='Bagging'))
    er_boosting_xgb = get_metrics(X,y,30,GradientBoosting(max_depth=3, n_estimators=150,base_tree='XGBoost'))
    er_sklearn_boosting = get_metrics(X,y,30,GDBSklearn(max_depth=3,n_estimators=150,learning_rate=0.2))

    #matplotlib inline
    data = [er_sklearn_boosting, er_boosting_xgb, er_boosting_bagging]
    fig7, ax7 = plt.subplots()
    ax7.set_title('')
    ax7.boxplot(data, labels=['GdbSklearn', 'Xgboost',  'XGBooBag'])
    plt.grid()
    plt.show()
