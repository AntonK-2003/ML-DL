import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn import svm
import os

def create_dataset(df):
    x = []
    y = []
    for i in range(100, df.shape[0]):
        x.append(df[i-100:i, 0])
        y.append(df[i, 0])
    x = np.array(x)
    y = np.array(y)
    return x,y

def SVM(df):

    df = df['Close'].values
    df = df.reshape(-1, 1)
    print(df.shape)
    df[:5]

    dataset_train = np.array(df[:int(df.shape[0]*0.8)])
    dataset_test = np.array(df[int(df.shape[0]*0.8)-100:])
    print(dataset_train.shape)
    print(dataset_test.shape)

    scaler = MinMaxScaler(feature_range=(0,1))
    dataset_train = scaler.fit_transform(dataset_train)
    dataset_train[:5]

    dataset_test = scaler.transform(dataset_test)
    dataset_test[:5]

    x_train, y_train = create_dataset(dataset_train)
    x_train[:1]

    x_test, y_test = create_dataset(dataset_test)
    x_test[:1]

    # Reshape features for LSTM Layer
    x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))
    x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))


    regression.fit(x, y)
    regression.predict()
