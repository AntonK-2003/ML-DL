from src.Prediction import predict
import MetaTrader5 as mt5
import numpy as np
import src.markets_analysis.Prediction.boost_test
import src.markets_analysis.Prediction.xgboost_test
import src.markets_analysis.Prediction.svm_regression
import pandas
import matplotlib.pyplot as plt 

df = pd.read_csv("src/Dataset/Data.csv")

boost(df)
SVM(df)
XGBoost(df)

