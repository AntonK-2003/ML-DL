#include <mlpack.hpp>

using namespace mlpack;


LinearRegression	(	const arma::mat & 	predictors,
const arma::rowvec & 	responses,
const double 	lambda = 0,
const bool 	intercept = true 
)
