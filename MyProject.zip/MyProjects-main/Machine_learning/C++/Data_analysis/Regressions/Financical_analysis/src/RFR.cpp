#include "stdafx.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "dataanalysis.h"
#include <mlpack>

using namespace alglib;


int decisionforestregression(int argc, char **argv)
{
    //
    // The very simple regression example: model f(x,y)=x+y
    //
    // First, we have to create DF builder object, load dataset and specify
    // training settings. Our dataset is specified as matrix, which has following
    // format:
    //
    //     x0 y0 f0
    //     x1 y1 f1
    //     x2 y2 f2
    //     ....
    //
    // Here xi and yi can be any values, and fi is a dependent function value.
    //
    // NOTE: you can also solve classification problems with DF models, see
    //       another example for this unit.
    //
    decisionforestbuilder builder;
    ae_int_t nvars = 2;
    ae_int_t nclasses = 1;
    ae_int_t npoints = 4;
    real_2d_array xy = "[[1,1,+2],[1,-1,0],[-1,1,0],[-1,-1,-2]]";

    dfbuildercreate(builder);
    dfbuildersetdataset(builder, xy, npoints, nvars, nclasses);

    // in our example we train decision forest using full sample - it allows us
    // to get zero classification error. However, in practical applications smaller
    // values are used: 50%, 25%, 5% or even less.
    dfbuildersetsubsampleratio(builder, 1.0);

    // we train random forest with just one tree; again, in real life situations
    // you typically need from 50 to 500 trees.
    ae_int_t ntrees = 1;
    decisionforest model;
    dfreport rep;
    dfbuilderbuildrandomforest(builder, ntrees, model, rep);

    // with such settings (full sample is used) you can expect zero RMS error on the
    // training set. Beautiful results, but remember - in real life you do not
    // need zero TRAINING SET error, you need good generalization.

    printf("%.4f\n", double(rep.rmserror)); // EXPECTED: 0.0000

    // now, let's perform some simple processing with dfprocess()
    real_1d_array x = "[+1,+1]";
    real_1d_array y = "[]";
    dfprocess(model, x, y);
    printf("%s\n", y.tostring(3).c_str()); // EXPECTED: [+2]

    // another option is to use dfprocess0() which returns just first component
    // of the output vector y. ideal for regression problems and binary classifiers.
    double y0;
    y0 = dfprocess0(model, x);
    printf("%.3f\n", double(y0)); // EXPECTED: 2.000

    // there also exist another convenience function, dfclassify(),
    // but it does not work for regression problems - it always returns -1.
    ae_int_t i;
    i = dfclassify(model, x);
    printf("%d\n", int(i)); // EXPECTED: -1
    return y0;
}
