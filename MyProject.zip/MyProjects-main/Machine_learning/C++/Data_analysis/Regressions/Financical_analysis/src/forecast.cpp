#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <time.h>
#include "opennn.h"

using namespace OpenNN;
using namespace std;
using namespace Eigen;

int main(void)
{
    // Data Set
    DataSet data_set("EUR_USD.csv",',',true);
    const Index lags_number = 1;
    const Index steps_ahead_number = 1;
    data_set.set_lags_number(lags_number);
    data_set.set_lags_number(steps_ahead_number);
    data_set.transform_time_series();
    const Index input_variables_number = data_set.get_input_variables_number();
    const Index target_variables_number = data_set.get_target_variables_number();
                
    // Neural Network
    const Index hidden_neurons_number = 7;
    NeuralNetwork neural_network(NeuralNetwork::Forecasting,
        {input_variables_number, hidden_neurons_number, target_variables_number});
                
    // Training Strategy
    TrainingStrategy training_strategy(&neural_network, &data_set);
    training_strategy.set_loss_method(TrainingStrategy::MEAN_SQUARED_ERROR);
    training_strategy.set_optimization_method(TrainingStrategy::ADAPTIVE_MOMENT_ESTIMATION);
                
    // Testing Analysis
    TestingAnalysis testing_analysis(&neural_network, &data_set);
    const Tensor<TestingAnalysis::LinearRegressionAnalysis, 1> linear_regression_analysis
    = testing_analysis.perform_linear_regression_analysis();
    linear_regression_analysis(0).print();
                
    // Model Deployment
    Tensor<type, 2> inputs = data_set.get_data();
    neural_network.calculate_outputs(inputs);
                
    // Save results
    neural_network.save_expression_c("expression.txt");
    neural_network.save_expression_python("expression.txt");
}
