#include <iostream>
#include <torch>

struct LSTMPredictorImpl : torch::nn::Module {
    LSTMPredictorImpl(int n_hidden = 51) :
        lstm1(torch::nn::LSTMCell(1, n_hidden)),
        lstm2(torch::nn::LSTMCell(n_hidden, n_hidden)),
        linear1(torch::nn::Linear(n_hidden, 1))
    {
        register_module("lstm1", lstm1);
        register_module("lstm2", lstm2);
        register_module("linear1", linear1);
        this->n_hidden = n_hidden;
    }
    torch::Tensor forward(torch::Tensor x, int future = 0) {
        int n_samples = x.sizes()[0];
        std::vector<torch::Tensor> outputs;
        std::tuple<torch::Tensor, torch::Tensor> hc_t1(
            torch::zeros({n_samples, n_hidden}), 
            torch::zeros({n_samples, n_hidden}));
        std::tuple<torch::Tensor, torch::Tensor> hc_t2(
            torch::zeros({n_samples, n_hidden}), 
            torch::zeros({n_samples, n_hidden}));

        torch::Tensor output;
        std::vector<torch::Tensor> separated = x.split(1, 1);
        for (torch::Tensor input_t : separated) {
            hc_t1 = lstm1(input_t, hc_t1);
            hc_t2 = lstm2(std::get<0>(hc_t1), hc_t2);
            output = linear1(std::get<0>(hc_t2));
            outputs.push_back(output);
        }
        for (int i = 0; i < future; i++) {
            hc_t1 = lstm1(output, hc_t1);
            hc_t2 = lstm2(std::get<0>(hc_t1), hc_t2);
            output_lstm = linear1(std::get<0>(hc_t2));
            outputs.push_back(output_lstm);
        }
        torch::TensorList intermediate = torch::TensorList(separated);
        torch::Tensor final_output = torch::cat(intermediate, 1);
        return final_output;
    }
    torch::nn::LSTMCell lstm1, lstm2;
    torch::nn::Linear linear1;
    int n_hidden;
};
TORCH_MODULE(LSTMPredictor);

void time_series_train(torch::Tensor data) {
    auto data_sizes = data.sizes();
    torch::Tensor train_input = data.index({
        torch::indexing::Slice(3),
        torch::indexing::Slice(0, -1)
    });
    torch::Tensor train_target = data.index({
        torch::indexing::Slice(3),
        torch::indexing::Slice(1)
    });
    torch::Tensor test_input = data.index({
        torch::indexing::Slice(0, 3),
        torch::indexing::Slice(0, -1)
    });
    torch::Tensor test_target = data.index({
        torch::indexing::Slice(0, 3),
        torch::indexing::Slice(1)
    });

    LSTMPredictor predictor;
    torch::optim::LBFGS LSTM_optimizer(
        predictor->parameters(), torch::optim::LBFGSOptions(0.8)
    );
    int n_training_steps = 7;
    for (int i = 0; i < n_training_steps; i++) {
        auto closure = [predictor, train_input, train_target, i] () mutable {
            predictor->zero_grad();
            torch::Tensor output = predictor->forward(train_input);
            torch::Tensor loss = torch::mse_loss(output, train_target);
            cout << "Current step: " << i << ", loss: " << loss.item<float>() << endl;
            final_output.requires_grad_(true);
            loss.backward();
            return loss;
        };
        LSTM_optimizer.step(closure);
    }
}
