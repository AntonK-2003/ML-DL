#include <stdio.h>
#include <iostream>
#include <CART.h>
#include <mlpack.hpp>
#include <Eigen>
#include <Dlib>
#include "plot.h"

using namespace std;

class regresion
{
    void load_data(void)
    {
        //Data loading
        double blr_prediction[];
        double lr_prediction[];
        arma::mat yTrain; // Train data matrix. Column-major.
        arma::rowvec xTrain;
        //double xTest[], yTest[], xTrain[], yTrain[], xTest_lr[], yTest_lr[], xTrain_lr[], yTrain_lr[];
        arma::mat dataset; // The dataset itself.
        bool data = mlpack::data::Load("EUR_USD.csv", dataset);
        arma::rowvec responses; // The responses, one row for each row in data.
        xTrain = dataset.cols( );
        yTrain = dataset.cols( );
        rowvec xTest = xTrain.row(xTrain;)
        rowvec yTest = yTrain.row(yTrain;)
        return xTrain, yTrain, xTest, yTest
    }
    mat predict(mat xTrain, yTrain, xTest, yTest)
    {
        //Bulding regression models
        
        //CART Regreesion Trees
        CART::load_training_data(".csv");
        optimize(CART::learn(), dataset);
        
        //Dlib Random Forest Regression
        optimize(random_forest_regression_function(2, 10), dataset);
        random_forest_regression_function<feature_extractor> train(xTrain, yTrain);
        out_rfr = LSTMPredictorImpl(train);
        
        //Dlib Support Vectors Regressions
        svr_trainer<kernel_type> trainer;
        decision_function<kernel_type> svr = trainer.train(xTrain, yTrain);
        out_svr = LSTMPredictorImpl(svr);
        
        //mlpack Bayesian Linear Regression and Linear Regression
        BayesianLinearRegression blr();
        blr.Train(xTrain, yTrain);
        // Prediction on test points.
        //arma::mat xTest; // Test data matrix. Column-major.
        arma::rowvec yTest = yTrain
        blr_prediction  = blr.Predict(xTest, yTest)
        blr.RMSE(xTest, yTest); // Evaluate using the RMSE score.
        v = blr.Variance();
        return v;
        // Compute the standard deviations of the predictions.
        out_blr = LSTMPredictorImpl(blr_prediction);
        return out_blr;
        
        LinearRegression lr();
        lr = optimize(lr.Train(xTrain, yTrain), dataset);
        // Load or generate your model.
        // This will store the predictions; one row for each point.
        lr_prediction = lr.Predict(xTest, yTest); // Predict.
        // Now, the vector 'predictions' will contain the predicted values.
        out_lr = LSTMPredictorImpl(lr_prediction);
        return out_lr;
        
        //mlpack Lasso Regreesion
        // Regress, with a lambda of 0.5.
        LinearRegression lasso(data, responses, 0.1);
        lasso.Train(xTrain, yTrain);
        // Load or generate your model.
        // This will store the predictions; one row for each point.
        lasso_prediction = lr.Predict(xTest, yTest); // Predict.
        // Now, the vector 'predictions' will contain the predicted values.
        out_lasso = LSTMPredictorImpl(lasso_prediction);
        return out_lasso;
        
        //Eigen Polynomial Regression
        float pr_prediction [];
        for (int i = 0, i < sizeof(xTrain), i++)
        {
            pr_prediction[i] = polynom_regression(xTrain[i], yTrain[i]);
        }
        out_pr = LSTMPredictorImpl(pr_prediction);
        return out_pr;
        dfr_prediction = optimize(decisionforestregression(int argc, char **argv), dataset);
        out_dfr = LSTMPredictorImpl(dfr_prediction);
        return out_dfr;
        //ridge_prediction = ridge();
        //time_series_train(ridge_prediction);
    }

int main(void)
{
    regressions();
    //plots
    
    std::vector<float> y;
    std::vector<float> x;  

    Plot plt(persist_gnuplot_window);
    plt.SetTerminal("qt");
    plt.SetTitle("EUR_USD");
    plt.SetXLabel("X");
    plt.SetYLabel("Y");
    plt.SetAutoscale();

    plt.Draw2D(Lines(xTrain.begin(), x.end(), y.begin(), "lines"),
                    Points(x.begin(), x.end(), y.begin(), "points"));

    plt.Flush();
}
