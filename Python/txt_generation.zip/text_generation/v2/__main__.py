from __future__ import absolute_import, division, print_function, unicode_literals!pip install tensorflow-gpu==2.0.0-alpha0
import tensorflow as tfimport numpy as np
import os
import datetimefrom tensorflow.python.client import device_lib
from google.colab import filesuploaded
import os
#print(device_lib.list_local_devices())
#print(“TensorFlow version: “, tf.__version__)

filesuploaded = files.upload()for fn in uploaded.keys():
    print(‘User uploaded file “{name}” with length {length}    bytes’.format(name=fn, length=len(uploaded[fn])))
    
import os
path = os.getcwd()text = open(path + ‘/Iliad_v3.txt’,  ‘rb’).read().decode(encoding=utf-8)
print(“Text is {} characters long”.format(len(text)))
words = [w for w in text.split(‘ ‘) if w.strip() != ‘’ or w == ‘\n’]
print(“Text is {} words long”.format(len(words)))
vocab = sorted(set(text))
print (‘There are {} unique characters’.format(len(vocab)))
char2int = {c:i for i, c in enumerate(vocab)}
int2char = np.array(vocab)
print(‘Vector:\n’)
for char,_ in zip(char2int, range(len(vocab))):
    print(‘ {:4s}: {:3d},’.format(repr(char), char2int[char]))
    
text_as_int = np.array([char2int[ch] for ch in text], dtype=np.int32)
print (‘{}\n mapped to integers:\n {}’.format(repr(text[:100]), text_as_int[:100]))

tr_text = text_as_int[:704000] 
val_text = text_as_int[704000:] print(text_as_int.shape, tr_text.shape, val_text.shape)
model = build_model(vocab_size, embedding_dim, rnn_units, batch_size=1)
model.load_weights(tf.train.latest_checkpoint(checkpoint_dir)) 
model.build(tf.TensorShape([1, None]))def generate_text(model, start_string):
    
    print('Generating with seed: "' + start_string + '"')
  
    num_generate = 1000    input_eval = [char2int[s] for s in start_string]
    input_eval = tf.expand_dims(input_eval, 0)    text_generated = []    temperature = 1.0    model.reset_states()
    for i in range(num_generate):
        predictions = model(input_eval)
        predictions = tf.squeeze(predictions, 0)
        predictions = predictions / temperature
        predicted_id = tf.random.categorical(predictions,      num_samples=1)[-1,0].numpy()
        input_eval = tf.expand_dims([predicted_id], 0)
        text_generated.append(int2char[predicted_id])    return (start_string + ''.join(text_generated))print(generate_text(model, start_string="joy of gods"))

