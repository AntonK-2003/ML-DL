from telebot import types
from pyairtable import Base
from chatbot.src.telegram import telegram
import telebot;

def get_text_messages(message, bot):
    bot.message_handler(content_types=['text', 'document', 'photo'])
    if message.text== "Привет":
        bot.send_message(message.from_user.id, "Чем я могу Вам помочь?")
    else:
        bot.send_message(message.from_user.id, "Я Вас не понимаю. Напишите /help.")
    
def start(message, bot):
    if message.text == '/reg':
        bot.send_message(message.from_user.id, "Отправьте фото с текстом");
        bot.register_next_step_handler(message, get_name); #следующий шаг – функция get_name
    else:
        bot.send_message(message.from_user.id, 'Напишите /reg');

def get_name(message, bot): #получаем фамилию
    global name;
    name = message.text;
    bot.send_message('Ваше имя:');
    bot.register_next_step_handler(message);
    return name    
        
def get_id(message, bot):
    global id;
    id = message.text;
    bot.send_message(message.from_user.id, 'Ваш id:');
    bot.register_next_step_handler(message);
    return id

def get_type(message, bot):
    global type;
    type = message.text;
    bot.send_message('Тип объекта');
    bot.register_next_step_handler(message);
    return type

def get_city(message, bot):
    global city;
    city = message.text;
    bot.send_message('Город:');
    bot.register_next_step_handler(message);
    return city
    
def get_hname(message, bot):
    global hname;
    hname = message.text;
    bot.send_message('Название здания:');
    bot.register_next_step_handler(message);
    return hname  
      
def get_area(message, bot):
    global area;
    area = message.text;
    bot.send_message('Район:');
    bot.register_next_step_handler(message);
    return area    
        
def get_metro(message, bot):
    global metro;
    metro = message.text;
    bot.send_message('Ближайшее метро');
    bot.register_next_step_handler(message);
    return metro

def get_nrooms(message, bot):
    global rooms;
    rooms = message.text;
    bot.send_message('Количество спален:');
    bot.register_next_step_handler(message);
    return rooms
    
def get_currency(message, bot):
    global currency;
    currency = message.text;
    bot.send_message('Валюта арендной ставки');
    bot.register_next_step_handler(message);
    return currency

def get_bid(message, bot):
    global bid;
    bid = message.text;
    bot.send_message('Ставка аренды в месяц:');
    bot.register_next_step_handler(message);
    return bid

def get_commission(message, bot):
    global commission;
    commission = message.text;
    bot.send_message('Комиссия агента:');
    bot.register_next_step_handler(message);
    return commission

def get_deposit(message, bot):
    global deposit;
    deposit = message.text;
    bot.send_message('Депозит: ');
    bot.register_next_step_handler(message);
    return deposit 
    
def get_access_period(message, bot):
    global period;
    period = message.text;
    bot.send_message('Срок доступа: ');
    bot.register_next_step_handler(message);
    return period

def get_floor(message, bot):
    global floor;
    floor = message.text;
    bot.send_message('Этаж: ');
    bot.register_next_step_handler(message);
    return floor

def get_head(message, bot):
    global head;
    head = message.text;
    bot.send_message('Заголовок объявления: ');
    bot.register_next_step_handler(message);
    return head

def get_lang(message, bot):
    global lang;
    bot.send_message('Выберите язык описания объявления: ')
    keyboard = types.InlineKeyboardMarkup(); #наша клавиатура
    key_1 = types.InlineKeyboardButton(text='Русский', callback_data='russian'); #кнопка «Да»
    keyboard.add(key_1); #добавляем кнопку в клавиатуру
    key_2= types.InlineKeyboardButton(text='Английский', callback_data='english');
    keyboard.add(key_2);
    key_3= types.InlineKeyboardButton(text='Хинди', callback_data='hindy');
    keyboard.add(key_3);
    key_4= types.InlineKeyboardButton(text='Турецкий', callback_data='turkish');
    keyboard.add(key_4);
    key_5= types.InlineKeyboardButton(text='Иврит', callback_data='Ivrit');
    keyboard.add(key_5);
    key_6= types.InlineKeyboardButton(text='Греческий', callback_data='Greek');
    keyboard.add(key_6);
    bot.send_message(message.from_user.id, text=question, reply_markup=keyboard)
    return lang

def get_description(message, bot):
    global description;
    description = message.text;
    bot.send_message('Описание: ');
    bot.register_next_step_handler(message);
    return description

def get_photo(img_path, bot):
    bot.send_document(chat_id=chat_id, document=open(img_path, 'rb'))

def get_params(message, bot):
    global params;
    bot.send_message('Наличие: ')
    keyboard = types.InlineKeyboardMarkup(); #наша клавиатура
    key_1 = types.InlineKeyboardButton(text='Балкона', callback_data='balcony'); #кнопка «Да»
    keyboard.add(key_1); #добавляем кнопку в клавиатуру
    key_2= types.InlineKeyboardButton(text='Собственной ванны', callback_data='own bash');
    keyboard.add(key_2);
    key_3= types.InlineKeyboardButton(text='Бассейна', callback_data='pool');
    keyboard.add(key_3);
    key_4= types.InlineKeyboardButton(text='Фитнес-зала', callback_data='gym');
    keyboard.add(key_4);
    key_5= types.InlineKeyboardButton(text='Охраняемой территории', callback_data='protected area');
    keyboard.add(key_5);
    key_6= types.InlineKeyboardButton(text='Кондиционер', callback_data='conditioner');
    keyboard.add(key_6);
    key_7= types.InlineKeyboardButton(text='Wi-Fi', callback_data='wifi');
    keyboard.add(key_7);
    key_8= types.InlineKeyboardButton(text='Кондиционер', callback_data='conditioner');
    keyboard.add(key_8);
    key_9= types.InlineKeyboardButton(text='Другое', callback_data='other');
    keyboard.add(key_9);
    if key_9:
        other_p = message.text;
        bot.send_message(message.from_user.id, text=other_p, reply_markup=keyboard)
    return params

def callback_worker(call, at, bot):
    if call.data == "yes": #call.data это callback_data, которую мы указали при объявлении кнопки
        at.update(table_name, "Имя", name)
        telegram.get_id(message)
        at.update(table_name, "ID", id)
        telegram.get_type(message)
        at.update(table_name, "Тип объекта", type)
        telegram.get_city(message)
        at.update(table_name, "Город", city)
        telegram.get_hname(message)
        at.update(table_name, "Название здания", hname)
        telegram.get_metro(message)
        at.update(table_name, "Ближайшее метро", metro)
        telegram.get_nrooms(message)
        at.update(table_name, "Количество спален", nrooms)
        telegram.get_currency(message)
        at.update(table_name, "Валюта арендной ставки", currency)
        telegram.get_bid(message)
        at.update(table_name, "Ставка арендной в месяц", bid)
        telegram.get_commission(message)
        at.update(table_name, "Комиссия агента", commission)
        telegram.get_deposit(message)
        at.update(table_name, "Депозит", deposit)
        telegram.get_access_period(message)
        at.update(table_name, "Срок доступа", period)
        telegram.get_floor(message)
        at.update(table_name, "Этаж", floor)
        telegram.get_head(message)
        at.update(table_name, "Заголовок объявления", head)
        telegram.get_lang(message)
        at.update(table_name, "Язык", lang)
        telegram.get_description(message)
        telegram.get_photo(img_path)
        at.update(table_name, "Фото", img_path)
        telegram.get_params(message)
        bot.callback_query_handler(func=lambda call: True) #код сохранения данных, или их обработки
        bot.send_message(call.message.chat.id, 'Запомню : )');
         


