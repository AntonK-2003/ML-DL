from chatbot.src.telegram import telegram
from pyairtable import Table
import openai
import os
import telebot

api_key = 'AIRTABLE_API_KEY'
base_id = 'base_id'

table_name = input()
at = Table(api_key, base_id, table_name)
name = '';
surname = '';
age = 0;
bot = telebot.TeleBot('6141669133:AAGmpB-au3G6Z6PD5tP2MQaMw_aGKHqOfDI');
bot.message_handler(content_types=['text'])
#message = input()
telegram.get_text_messages(message, bot)
telegram.start(message, bot)
telegram.get_name(message, bot)
telegram.callback_worker(call, at, bot)

content = 'summarize text' + name + id + type + city + hname + area + metro + rooms + currency + bid + commission + deposit + period + description messages.append({"content": content})
completion = openai.ChatCompletion.create(
    model="gpt-3.5-turbo",
    messages=messages
)

chat_response = completion.choices[0].message.content
print(f'ChatGPT: {chat_response}')
messages.append({"content": chat_response})

at.create(table_name, {"Имя": name, "id": id, "Тип объекта": type, "Город": city, "Название здания": hmane, "Район": area, "Ближайшее метро": metro, "Количество спален": rooms, "Валюта арендной ставки": currency, "Ставка аренды в месяц": bid, "Комиссия агента": commission, "Депозит": deposit, "Срок доступа": period, "Этаж": floor, "Заголовок объявления": head, "Описание объявления": description, "Фото": img_path, "Наличие": params})
bot.polling(none_stop=True, interval=0)
