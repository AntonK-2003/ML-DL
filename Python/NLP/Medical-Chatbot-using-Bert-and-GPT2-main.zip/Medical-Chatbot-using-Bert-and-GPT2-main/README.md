# Medical-Chatbot-using-Bert-and-GPT2

In this repository, I have shown how we can use BioBert and GPT-2 to generate answer to the medical questions asked by a patient. 

It also involves retrieving previously answered question-answer pairs that are similar to the given patient question. 

Please refer to sample_input_output4.PNG image for sample input and output.

Please go through the blog https://suniljammalamadaka.medium.com/medical-chatbot-using-bert-and-gpt2-62f0c973162f to know more.
