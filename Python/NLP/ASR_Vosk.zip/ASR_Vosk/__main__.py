from ASR_Vosk.src import ASR_Vosk
from ASR_Vosk.src import with_microphone

print("Путь до модели:")
model_path = input()
print("Меню (выберите число):")
print("1. Распознавание с потока")
print("2. Распознавание с аудиофайла")
c = int(input())

if c == 1:
    with_microphone.ASR_stream(model_path)
else:
    print("Путь до аудиофайла:")
    audio_path_path = input()
    ASR_Vosk.ASR(audio_path, model_path)
    with open("out.json", "w") as f:
        f.write(result)
