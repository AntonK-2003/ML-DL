# This file is to be executed when a phrase has a response. 

# This text might be helpful for internet searches!!
# google-chrome www.google.com/?q=$2
# x-www-browser www.google.com/?q=$2
# xdg-email
# libreoffice
# echo $@
# echo $0
#echo "my name is human.  as soon as you arrived, i recognized your voice.  i recognized who you are, because i know who you are to me too. your name is jane.  is it not? - yes, your name is human."
