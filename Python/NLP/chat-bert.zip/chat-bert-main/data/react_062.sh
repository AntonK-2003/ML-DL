# This file is to be executed when a phrase has a response. 

# This text might be helpful for internet searches!!
# google-chrome www.google.com/?q=$2
# x-www-browser www.google.com/?q=$2
# xdg-email
# libreoffice
# echo $@
# echo $0
#echo "it would take the world seven point five billion years to get from the center of the universe to the center of the galaxy. - it is pretty hard to find our world in a galaxy that is that big."
