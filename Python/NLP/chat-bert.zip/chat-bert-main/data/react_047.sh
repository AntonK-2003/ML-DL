# This file is to be executed when a phrase has a response. 

# This text might be helpful for internet searches!!
# google-chrome www.google.com/?q=$2
# x-www-browser www.google.com/?q=$2
# xdg-email
# libreoffice
# echo $@
# echo $0
#echo "the time spent on an airplane is wasted time. why should we spend time flying when we can do more meaningful things with that time, like meet women? - there has got to be more to life than that. why should everything we do in life have to lead to the same end? do you really"
