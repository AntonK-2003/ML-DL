# This file is to be executed when a phrase has a response. 

# This text might be helpful for internet searches!!
# google-chrome www.google.com/?q=$2
# x-www-browser www.google.com/?q=$2
# xdg-email
# libreoffice
# echo $@
# echo $0
#echo "i know how to read and write. - what is your name?"
