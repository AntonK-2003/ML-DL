# This file is to be executed when a phrase has a response. 

# This text might be helpful for internet searches!!
# google-chrome www.google.com/?q=$2
# x-www-browser www.google.com/?q=$2
# xdg-email
# libreoffice
# echo $@
# echo $0
#echo "yes i can't believe it! - oh yeah, she is a good artist too. well she's got a really great portfolio. you know what, you should ask her out."
