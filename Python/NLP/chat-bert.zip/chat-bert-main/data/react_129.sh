# This file is to be executed when a phrase has a response. 

# This text might be helpful for internet searches!!
# google-chrome www.google.com/?q=$2
# x-www-browser www.google.com/?q=$2
# xdg-email
# libreoffice
# echo $@
# echo $0
#echo "well then, i suppose you should go practice your violin while i review the last issue of the paper. - ok, your majesty."
