# VIRTUALENV

Source the file named `do_make_virtualenv_setup310.sh` .

```
. ./do_make_virtualenv_setup310.sh 
```

# Requirements

After sourcing the above file, run this command to install dependencies.

```
pip3 install -r ./requirements.x86_64.txt 
## Exit this folder and use repository normally... ##
```
