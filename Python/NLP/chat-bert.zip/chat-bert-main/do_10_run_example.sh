cd ./src/ 

./main.py --no_repeats
