rm ./cornell_movie_dialogs_corpus.zip*
rm -fr ./__MACOSX/
rm -fr ./cornell\ movie-dialogs\ corpus/
rm movie_lines.txt

