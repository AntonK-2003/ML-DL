cd ./src/ 

./query_gpt.py --length 300 
