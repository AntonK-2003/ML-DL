cd raw/

wget http://www.cs.cornell.edu/~cristian/data/cornell_movie_dialogs_corpus.zip 

unzip cornell_movie_dialogs_corpus.zip

cd ./cornell\ movie-dialogs\ corpus/ 

cp movie_lines.txt ..

echo "see document called movie_lines.txt"

