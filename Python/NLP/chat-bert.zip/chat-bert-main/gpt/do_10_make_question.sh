cd ./src/ 


./convert_dialog_tab.py ../raw/movie_lines.txt --do_format 


