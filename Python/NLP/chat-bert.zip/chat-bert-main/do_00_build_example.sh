cd ./src/ 

./build_files.py --write 

./build_multipliers.py --write --batch
#./build_multipliers.py --write --room 1 --list  
#./build_multipliers.py --write --room 2 --list 
#./build_multipliers.py --write --room 3 --list 
#./build_multipliers.py --write --room 4 --list 
#./build_multipliers.py --write --room 5 --list 

echo "example using rooms 1,2,3,4 and 5"
